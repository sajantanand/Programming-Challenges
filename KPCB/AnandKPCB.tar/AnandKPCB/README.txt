Name:		Sajant Anand
Date:		October 16, 2015
Purpose:	KPCB Engineering Fellows Challenge Problem

Description: Implementation of fixed size hash table in C++

Instructions:
	1. To compile:	"make"
	2. To run:	"make run"
